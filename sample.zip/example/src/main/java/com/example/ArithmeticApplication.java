/*package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@EnableAutoConfiguration
@SpringBootApplication

@RequestMapping("/arithmetic")
public class ArithmeticApplication {

	@RequestMapping(value = "/add/a/{a}/b/{b}", method = RequestMethod.GET)
	public @ResponseBody String find_Sum(@PathVariable int a, @PathVariable int b) {
		int sum = a + b;
		return "Addition is " + sum;
	}

	@RequestMapping(value = "/sub/a/{a}/b/{b}", method = RequestMethod.GET)
	public @ResponseBody String find_Sub(@PathVariable int a, @PathVariable int b) {
		int sub = a - b;
		return "Subtraction is " + sub;
	}

	@RequestMapping(value = "/mul/a/{a}/b/{b}", method = RequestMethod.GET)
	public @ResponseBody String find_Mul(@PathVariable int a, @PathVariable int b) {
		int Mul = a * b;
		return "Multiplication is " + Mul;
	}

	@RequestMapping(value = "/div/a/{a}/b/{b}", method = RequestMethod.GET)
	public @ResponseBody String find_Div(@PathVariable int a, @PathVariable int b) {
		int Div = a / b;
		return "Division is " + Div;
	}

	public static void main(String[] args) {
		SpringApplication.run(ArithmeticApplication.class, args);

	}

}
*/