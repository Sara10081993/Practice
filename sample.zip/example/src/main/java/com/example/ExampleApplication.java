package com.example;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
//import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
//import org.springframework.web.bind.annotation.ResponseBody;
//Tells Spring to consider this bean for handling incoming web requests
@Controller
//Tells Spring to guess application type based on its dependencies and
//setup application context accordingly:
@EnableAutoConfiguration
@SpringBootApplication
@RequestMapping("/example")
public class ExampleApplication {
	 
	   /* // Tells to convert return value into HTTP response:
	    @ResponseBody
	   @RequestMapping("/helloworld")
	    String home() {
	        return "Hello , Spring Boot World!";
	    }*/
	@ResponseBody
	@RequestMapping(value = "/txt")
	public String readFile(String sample) throws IOException {
		 //BufferedReader br = new BufferedReader(new FileReader("src/main/resources/sample.txt"));
		  BufferedReader br = new BufferedReader(new FileReader("src/main/resources/test.txt"));

		    try {
		        StringBuilder sb = new StringBuilder();
		        String line = br.readLine();

		        while (line != null) {
		            sb.append(line);
		        	sb.append("\n");
		            line = br.readLine();
		            sb.append("\n");
		        }
		        return sb.toString();
		    } finally {
		        br.close();
		    }
		}

	public static void main(String[] args) {
		SpringApplication.run(ExampleApplication.class, args);
	}
}
